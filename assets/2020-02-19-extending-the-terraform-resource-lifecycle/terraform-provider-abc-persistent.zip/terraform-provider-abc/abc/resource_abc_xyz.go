package abc

import (
    "strings"

    "github.com/hashicorp/terraform-plugin-sdk/helper/schema"
    "github.com/stefaanc/terraform-provider-abc/api"
)

func resourceABCXYZ() *schema.Resource {
    return &schema.Resource{
        Schema: map[string]*schema.Schema{
            "name": &schema.Schema{
                Type:     schema.TypeString,
                Required: true,
                ForceNew: true,
            },
            "status": &schema.Schema{
                Type:     schema.TypeString,
                Optional: true,
                Default:  "closed",
            },

            "x_lifecycle": &schema.Schema{
                Type:     schema.TypeList,
                MaxItems: 1,
                Optional: true,
                Computed: true,
                Elem: &schema.Resource{
                    Schema: map[string]*schema.Schema{
                        "ignore_error_if_not_exists": &schema.Schema{
                            Type:     schema.TypeBool,
                            Optional: true,
                            Default:  false,
                        },
                        "exists": &schema.Schema{
                            Type:     schema.TypeBool,
                            Computed: true,
                        },
                    },
                },
            },

            "original": &schema.Schema{
                Type:     schema.TypeList,
                Computed: true,
                Elem: resourceABCXYZOriginal(),
            },
        },

        Create: resourceABCXYZCreate,
        Read:   resourceABCXYZRead,
        Update: resourceABCXYZUpdate,
        Delete: resourceABCXYZDelete,
    }
}

func resourceABCXYZOriginal() *schema.Resource {
    return &schema.Resource{
        Schema: map[string]*schema.Schema{
            "status": &schema.Schema{
                Type:     schema.TypeString,
                Computed: true,
            },
        },
    }
}

func resourceABCXYZCreate(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the configured attributes of the resource
    name   := d.Get("name").(string)
    status := d.Get("status").(string)

    // get the embedded `x_lifecycle` resource
    x_lifecycle := make(map[string]interface{})
    listOfInterfaces1, ok := d.GetOk("x_lifecycle")
    if ok {
        listOfInterfaces2 := listOfInterfaces1.([]interface{})
        if len(listOfInterfaces2) > 0 {
            x_lifecycle = listOfInterfaces2[0].(map[string]interface{})
        }
    }

    // read the resource's information from the infrastructure
    xyz, err := c.ReadXYZ(name)
    if err != nil {

        // lifecycle customizations: `ignore_error_if_not_exists`
        v, ok := x_lifecycle["ignore_error_if_not_exists"]
        if ok && v.(bool) && strings.Contains(err.Error(), "cannot find xyz") {

            // set zeroed Terraform state
            d.Set("name",   "")
            d.Set("status", "")
            d.Set("original", []interface{}{ })

            // set computed lifecycle attributes
            x_lifecycle["exists"] = false
            d.Set("x_lifecycle", []interface{}{ x_lifecycle })

            // set id
            d.SetId(name)

            return nil
        }

        // no lifecycle customizations
        return err
    }

    // set computed original infrastructure attributes, so they can be restored on destroy
    original := make(map[string]interface{})
    original["status"] = xyz.Status
    d.Set("original", []interface{}{ original })

    // set computed lifecycle attributes
    x_lifecycle["exists"] = true
    d.Set("x_lifecycle", []interface{}{ x_lifecycle })

    // check diff between the resource's Terraform configuration and infrastructure
    if !resourceABCXYZDiff(d, xyz) {
        // no update required - complete read

        // set Terraform state
        d.Set("name",   xyz.Name)
        d.Set("status", xyz.Status)

        // set id
        d.SetId(name)

        return nil

    } else {
        // update

        // update the resource in the infrastructure
        err := c.UpdateXYZ(name, status)
        if err != nil {
            return err
        }

        // set id
        d.SetId(name)

        return resourceABCXYZRead(d, m)
    }
}

func resourceABCXYZDiff(d *schema.ResourceData, xyz *api.XYZ) bool {
    if v, ok := d.GetOk("status"); ok && ( xyz.Status != v.(string) ) {
        return true
    }

    return false
}

func resourceABCXYZRead(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the identifying attributes of the resource
    name := d.Get("name").(string)

    // get the embedded `x_lifecycle` resource
    x_lifecycle := make(map[string]interface{})
    listOfInterfaces1, ok := d.GetOk("x_lifecycle")
    if ok {
        listOfInterfaces2 := listOfInterfaces1.([]interface{})
        if len(listOfInterfaces2) > 0 {
            x_lifecycle = listOfInterfaces2[0].(map[string]interface{})
        }
    }

    // read the resource's information from the infrastructure
    xyz, err := c.ReadXYZ(name)
    if err != nil {

        // lifecycle customizations: `ignore_error_if_not_exists`
        v, ok := x_lifecycle["ignore_error_if_not_exists"]
        if ok && v.(bool) && strings.Contains(err.Error(), "cannot find xyz") {

            // set zeroed Terraform state
            d.Set("name",   "")
            d.Set("status", "")
            d.Set("original", []interface{}{ })

            // set computed lifecycle attributes
            x_lifecycle["exists"] = false
            d.Set("x_lifecycle", []interface{}{ x_lifecycle })

            return nil
        }

        // no lifecycle customizations
        d.SetId("")
        return nil
    }

    // set Terraform state
    d.Set("name",   xyz.Name)
    d.Set("status", xyz.Status)

    // set computed lifecycle attributes
    x_lifecycle["exists"] = true
    d.Set("x_lifecycle", []interface{}{ x_lifecycle })

    return nil
}

func resourceABCXYZUpdate(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the configured attributes of the resource
    name   := d.Get("name").(string)
    status := d.Get("status").(string)

    // update the resource in the infrastructure
    err := c.UpdateXYZ(name, status)
    if err != nil {
        return err
    }

    return resourceABCXYZRead(d, m)
}

func resourceABCXYZDelete(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the identifying attributes of the resource
    name := d.Get("name").(string)

    // get the embedded `original` resource
    original := map[string]interface{}( nil )
    listOfInterfaces1, ok := d.GetOk("original")
    if ok {
        listOfInterfaces2 := listOfInterfaces1.([]interface{})
        if len(listOfInterfaces2) > 0 {
            original = listOfInterfaces2[0].(map[string]interface{})
        }
    }

    // update the resource in the infrastructure
    if original != nil {
        err := c.UpdateXYZ(name, original["status"].(string))
        if err != nil {
            return err
        }
    }

    // set id
    d.SetId("")

    return nil
}