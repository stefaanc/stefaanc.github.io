package abc

import (
    "strings"

    "github.com/hashicorp/terraform-plugin-sdk/helper/schema"
    "github.com/stefaanc/terraform-provider-abc/api"
)

func dataSourceABCXYZ() *schema.Resource {
    return &schema.Resource{
        Schema: map[string]*schema.Schema{
            "name": &schema.Schema{
                Type:     schema.TypeString,
                Required: true,
            },
            "status": &schema.Schema{
                Type:     schema.TypeString,
                Computed: true,
            },

            "x_lifecycle": &schema.Schema{
                Type:     schema.TypeList,
                MaxItems: 1,
                Optional: true,
                Computed: true,
                Elem: &schema.Resource{
                    Schema: map[string]*schema.Schema{
                        "ignore_error_if_not_exists": &schema.Schema{
                            Type:     schema.TypeBool,
                            Optional: true,
                            Default:  false,
                        },
                        "exists": &schema.Schema{
                            Type:     schema.TypeBool,
                            Computed: true,
                        },
                    },
                },
            },
        },

        Read: dataSourceABCXYZRead,
    }
}

func dataSourceABCXYZRead(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the identifying attributes of the data-source
    name := d.Get("name").(string)

    // get the embedded `x_lifecycle` resource
    x_lifecycle := make(map[string]interface{})
    listOfInterfaces1, ok := d.GetOk("x_lifecycle")
    if ok {
        listOfInterfaces2 := listOfInterfaces1.([]interface{})
        if len(listOfInterfaces2) > 0 {
            x_lifecycle = listOfInterfaces2[0].(map[string]interface{})
        }
    }

    // read the data-source's information from the infrastructure
    xyz, err := c.ReadXYZ(name)
    if err != nil {

        // lifecycle customizations: `ignore_error_if_not_exists`
        v, ok := x_lifecycle["ignore_error_if_not_exists"]
        if ok && v.(bool) && strings.Contains(err.Error(), "cannot find xyz") {

            // set zeroed Terraform state
            d.Set("name",   "")
            d.Set("status", "")

            // set computed lifecycle attributes
            x_lifecycle["exists"] = false
            d.Set("x_lifecycle", []interface{}{ x_lifecycle })

            // set id
            d.SetId(name)

            return nil
        }

        // no lifecycle customizations
        return err
    }

    // set Terraform state
    d.Set("name",   xyz.Name)
    d.Set("status", xyz.Status)

    // set computed lifecycle attributes
    x_lifecycle["exists"] = true
    d.Set("x_lifecycle", []interface{}{ x_lifecycle })

    // set id
    d.SetId(name)

    return nil
}