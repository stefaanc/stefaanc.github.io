package api

import (
)

type ABCClient struct {
    Name string
}