package api

import (
    "encoding/json"
    "fmt"
    "io/ioutil"
    "os"
    "strings"
)

type XYZ struct {
    Name   string
    Status string
}

func (c *ABCClient) CreateXYZ(name string, status string) error {
    // create the resource in the infrastructure

    file := fmt.Sprintf("./%s.json", name)

    _, err := os.Stat(file)
    if err == nil {
        err = fmt.Errorf("CreateXYZ(%q): xyz already exists.", name)
        return err
    }

    resource := XYZ{
        Name:   name,
        Status: status,
    }
    content, err := json.MarshalIndent(resource, "", "    ")
    if err != nil {
        return err
    }

    err = ioutil.WriteFile(file, content, 0644)
    if err != nil {
        return err
    }

    return nil
}

func (c *ABCClient) ReadXYZ(name string) (xyz *XYZ, err error) {
    // read the data-source's information from the infrastructure

    file := fmt.Sprintf("./%s.json", name)

    content, err := ioutil.ReadFile(file)
    if err != nil {
        if strings.Contains(err.Error(), "The system cannot find the file specified.") {
            err = fmt.Errorf("ReadXYZ(%q): cannot find xyz.", name)
        }
        return nil, err
    }

    xyz = new(XYZ)
    err = json.Unmarshal(content, xyz)
    if err != nil {
        return nil, err
    }

    return xyz, nil
}

func (c *ABCClient) UpdateXYZ(name string, status string) error {
    // update the resource in the infrastructure

    file := fmt.Sprintf("./%s.json", name)

    resource := XYZ{
        Name:   name,
        Status: status,
    }
    content, err := json.MarshalIndent(resource, "", "    ")
    if err != nil {
        return err
    }

    err = ioutil.WriteFile(file, content, 0644)
    if err != nil {
        return err
    }

    return nil
}

func (c *ABCClient) DeleteXYZ(name string) error {
    // delete the resource from the infrastructure

    file := fmt.Sprintf("./%s.json", name)

    err := os.Remove(file)
    if err != nil {
        return err
    }

    return nil
}