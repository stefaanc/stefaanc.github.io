package abc

import (
    "github.com/hashicorp/terraform-plugin-sdk/terraform"
    "github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func Provider() terraform.ResourceProvider {
    return &schema.Provider{
        Schema: map[string]*schema.Schema {
            // config attributes
            "name": &schema.Schema{
                Type:     schema.TypeString,
                Optional: true,
                Default: "my-host",
            },
        },

        DataSourcesMap: map[string]*schema.Resource {
            "abc_xyz": dataSourceABCXYZ(),
        },

        ResourcesMap: map[string]*schema.Resource{
            "abc_xyz": resourceABCXYZ(),
        },

        ConfigureFunc: providerConfigure,
    }
}

func providerConfigure(d *schema.ResourceData) (interface{}, error) {
    config := Config{
        Name: d.Get("name").(string),
    }

    return config.Client()
}