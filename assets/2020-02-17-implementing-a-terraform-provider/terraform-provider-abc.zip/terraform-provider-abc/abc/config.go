package abc

import (
    "github.com/stefaanc/terraform-provider-abc/api"
)

type Config struct {
    // config attributes
    Name string
}

func (c *Config) Client() (interface {}, error) {
    // process the attributes of the provider's configuration `c`, and initialize the provider API
    client := new(api.ABCClient)
    client.Name = c.Name

    return client, nil
}