package api

import (
)

type XYZ struct {
    Name   string
    Status string
}

func (c *ABCClient) CreateXYZ(name string, status string) error {
    // create the resource in the infrastructure
    // for this post, we do nothing

    return nil
}

func (c *ABCClient) ReadXYZ(name string) (xyz *XYZ, err error) {
    // read the data-source's information from the infrastructure
    // for this post, we are just returning some values
    xyz = new(XYZ)
    xyz.Name   = name
    xyz.Status = "open"

    return xyz, nil
}

func (c *ABCClient) UpdateXYZ(name string, status string) error {
    // update the resource in the infrastructure
    // for this post, we do nothing

    return nil
}

func (c *ABCClient) DeleteXYZ(name string) error {
    // delete the resource from the infrastructure
    // for this post, we do nothing

    return nil
}