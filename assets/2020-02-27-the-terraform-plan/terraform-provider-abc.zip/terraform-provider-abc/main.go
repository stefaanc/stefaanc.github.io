package main

import (
    "github.com/hashicorp/terraform-plugin-sdk/plugin"
    "github.com/stefaanc/terraform-provider-abc/abc"
)

func main() {
    plugin.Serve(&plugin.ServeOpts{
        ProviderFunc: abc.Provider,
    })
}