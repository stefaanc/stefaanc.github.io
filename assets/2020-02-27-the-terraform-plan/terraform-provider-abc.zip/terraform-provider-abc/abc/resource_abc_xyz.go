package abc

import (
    "github.com/hashicorp/terraform-plugin-sdk/helper/schema"
    "github.com/stefaanc/terraform-provider-abc/api"
)

func resourceABCXYZ() *schema.Resource{
    return &schema.Resource{
        Schema: map[string]*schema.Schema{
            "name": &schema.Schema{
                Type:     schema.TypeString,
                Required: true,
                ForceNew: true,
            },

            "a_required": &schema.Schema{
                Type:     schema.TypeString,
                Required: true,
            },
            "a_optional": &schema.Schema{
                Type:     schema.TypeString,
                Optional: true,
            },
            "a_optional_default": &schema.Schema{
                Type:     schema.TypeString,
                Optional: true,
                Default:  "default",
            },
            "a_optional_computed": &schema.Schema{
                Type:     schema.TypeString,
                Optional: true,
                Computed: true,
            },
            "a_computed": &schema.Schema{
                Type:     schema.TypeString,
                Computed: true,
            },

            "embedded": &schema.Schema{
                Type:     schema.TypeList,
                // Required: true,
                Optional: true,
                // Computed: true,                                              // see also in api/xyz.go for changes when Computed or Optional-Computed
                // ConfigMode: schema.SchemaConfigModeAttr,                     // see also in api/xyz.go for changes when schema.SchemaConfigModeAttr
                // MaxItems: 1,
                Elem: &schema.Resource{
                    Schema: map[string]*schema.Schema{
                        "b_required": &schema.Schema{
                            Type:     schema.TypeString,
                            Required: true,
                        },
                        "b_optional": &schema.Schema{
                            Type:     schema.TypeString,
                            Optional: true,
                        },
                        "b_optional_default": &schema.Schema{
                            Type:     schema.TypeString,
                            Optional: true,
                            Default:  "default",
                        },
                        "b_optional_computed": &schema.Schema{
                            Type:     schema.TypeString,
                            Optional: true,
                            Computed: true,
                        },
                        "b_computed": &schema.Schema{
                            Type:     schema.TypeString,
                            Computed: true,
                        },
                    },
                },
            },
        },

        Create: resourceABCXYZCreate,
        Read:   resourceABCXYZRead,
        Update: resourceABCXYZUpdate,
        Delete: resourceABCXYZDelete,
    }
}

func resourceABCXYZCreate(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the configured attributes of the resource
    name   := d.Get("name").(string)

    properties := &api.XYZ{
        Name:              name,
        ARequired:         d.Get("a_required").(string),
        AOptional:         d.Get("a_optional").(string),
        AOptionalDefault:  d.Get("a_optional_default").(string),
        AOptionalComputed: d.Get("a_optional_computed").(string),
    }

    if e, ok := d.GetOk("embedded"); ok {
        embedded := e.([]interface{})
        properties.Embedded = make([]*api.XYZEmbedded, len(embedded), len(embedded))

        for i, r := range embedded {
            resource := r.(map[string]interface{})
            properties.Embedded[i] = &api.XYZEmbedded{
                BRequired:         resource["b_required"].(string),
                BOptional:         resource["b_optional"].(string),
                BOptionalDefault:  resource["b_optional_default"].(string),
                BOptionalComputed: resource["b_optional_computed"].(string),
            }
        }
    }

    // create the resource in the infrastructure
    err := c.CreateXYZ(name, properties)
    if err != nil {
        return err
    }

    // set id
    d.SetId(name)

    return resourceABCXYZRead(d, m)
}

func resourceABCXYZRead(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the identifying attributes of the resource
    name := d.Get("name").(string)

    // read the data-source's information from the infrastructure
    xyz, err := c.ReadXYZ(name)
    if err != nil {
        d.SetId("")
        return nil
    }

    // set Terraform state
    d.Set("name", xyz.Name)

    d.Set("a_required",          xyz.ARequired)
    if xyz.AOptional != "" {
        d.Set("a_optional",          xyz.AOptional)
    }
    d.Set("a_optional_default",  xyz.AOptionalDefault)
    d.Set("a_optional_computed", xyz.AOptionalComputed)
    d.Set("a_computed",          xyz.AComputed)

    if len(xyz.Embedded) > 0 {
        embedded := make([]map[string]interface{}, len(xyz.Embedded), len(xyz.Embedded))
        for i, r := range xyz.Embedded {
            embedded[i] = map[string]interface{}{
                "b_required":          r.BRequired,
                "b_optional_default":  r.BOptionalDefault,
                "b_optional_computed": r.BOptionalComputed,
                "b_computed":          r.BComputed,
            }
            if r.BOptional != "" {
                embedded[i]["b_optional"] = r.BOptional
            }
        }
        d.Set("embedded", embedded)
    }

    return nil
}

func resourceABCXYZUpdate(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the configured attributes of the resource
    name   := d.Get("name").(string)

    properties := &api.XYZ{
        Name:              name,
        ARequired:         d.Get("a_required").(string),
        AOptional:         d.Get("a_optional").(string),
        AOptionalDefault:  d.Get("a_optional_default").(string),
        AOptionalComputed: d.Get("a_optional_computed").(string),
    }

    if e, ok := d.GetOk("embedded"); ok {
        embedded := e.([]interface{})
        properties.Embedded = make([]*api.XYZEmbedded, len(embedded), len(embedded))

        for i, r := range embedded {
            resource := r.(map[string]interface{})
            properties.Embedded[i] = &api.XYZEmbedded{
                BRequired:         resource["b_required"].(string),
                BOptional:         resource["b_optional"].(string),
                BOptionalDefault:  resource["b_optional_default"].(string),
                BOptionalComputed: resource["b_optional_computed"].(string),
            }
        }
    }

    // update the resource in the infrastructure
    err := c.UpdateXYZ(name, properties)
    if err != nil {
        return err
    }

    return resourceABCXYZRead(d, m)
}

func resourceABCXYZDelete(d *schema.ResourceData, m interface{}) error {
    c := m.(*api.ABCClient)

    // get the identifying attributes of the resource
    name := d.Get("name").(string)

    // delete the resource from the infrastructure
    err := c.DeleteXYZ(name)
    if err != nil {
        return err
    }

    // set id
    d.SetId("")

    return nil
}